import { toText, printf, interpolate, toConsole } from "./.fable/fable-library.3.2.9/String.js";
import { iAmAVeryLongAndEasilySearchableName } from "./SearchMe.fs.js";
import { Record, Union } from "./.fable/fable-library.3.2.9/Types.js";
import { string_type, record_type, int32_type, union_type } from "./.fable/fable-library.3.2.9/Reflection.js";
import { collect, toArray, map, singleton, append, delay, toList } from "./.fable/fable-library.3.2.9/Seq.js";
import { rangeDouble } from "./.fable/fable-library.3.2.9/Range.js";
import { createAtom, randomNext, int32ToString } from "./.fable/fable-library.3.2.9/Util.js";
import shuffle from "shuffle";
import playingCard from "../node_modules/shuffle/src/playingCard.js";
import { value, some } from "./.fable/fable-library.3.2.9/Option.js";

toConsole(interpolate("%P()", [iAmAVeryLongAndEasilySearchableName]));

export class Cards_Suit extends Union {
    constructor(tag, ...fields) {
        super();
        this.tag = (tag | 0);
        this.fields = fields;
    }
    cases() {
        return ["Hearts", "Clubs", "Diamonds", "Spades"];
    }
}

export function Cards_Suit$reflection() {
    return union_type("App.Cards.Suit", [], Cards_Suit, () => [[], [], [], []]);
}

export class Cards_Rank extends Union {
    constructor(tag, ...fields) {
        super();
        this.tag = (tag | 0);
        this.fields = fields;
    }
    cases() {
        return ["Value", "Ace", "King", "Queen", "Jack"];
    }
}

export function Cards_Rank$reflection() {
    return union_type("App.Cards.Rank", [], Cards_Rank, () => [[["Item", int32_type]], [], [], [], []]);
}

export function Cards_Rank_GetAllRanks() {
    return toList(delay(() => append(singleton(new Cards_Rank(1)), delay(() => append(map((i) => (new Cards_Rank(0, i)), rangeDouble(2, 1, 10)), delay(() => append(singleton(new Cards_Rank(4)), delay(() => append(singleton(new Cards_Rank(3)), delay(() => singleton(new Cards_Rank(2))))))))))));
}

export class Cards_Card extends Record {
    constructor(Suit, Rank) {
        super();
        this.Suit = Suit;
        this.Rank = Rank;
    }
}

export function Cards_Card$reflection() {
    return record_type("App.Cards.Card", [], Cards_Card, () => [["Suit", Cards_Suit$reflection()], ["Rank", Cards_Rank$reflection()]]);
}

export const Cards_fullDeck = toArray(delay(() => collect((suit) => map((rank) => (new Cards_Card(suit, rank)), Cards_Rank_GetAllRanks()), [new Cards_Suit(0), new Cards_Suit(2), new Cards_Suit(1), new Cards_Suit(3)])));

export function Cards_showPlayingCard(c) {
    let rankString;
    const matchValue = c.Rank;
    switch (matchValue.tag) {
        case 2: {
            rankString = "King";
            break;
        }
        case 3: {
            rankString = "Queen";
            break;
        }
        case 4: {
            rankString = "Jack";
            break;
        }
        case 0: {
            const n = matchValue.fields[0] | 0;
            rankString = int32ToString(n);
            break;
        }
        default: {
            rankString = "Ace";
        }
    }
    let suitString;
    const matchValue_1 = c.Suit;
    switch (matchValue_1.tag) {
        case 2: {
            suitString = "diamonds";
            break;
        }
        case 3: {
            suitString = "spades";
            break;
        }
        case 0: {
            suitString = "hearts";
            break;
        }
        default: {
            suitString = "clubs";
        }
    }
    return (rankString + " of ") + suitString;
}

export function Cards_printAllCards() {
    for (let idx = 0; idx <= (Cards_fullDeck.length - 1); idx++) {
        const card = Cards_fullDeck[idx];
        const arg10 = Cards_showPlayingCard(card);
        toConsole(printf("%s"))(arg10);
    }
}

export function Cards_drawOneAndPrintCard() {
    const rand = {};
    return Cards_showPlayingCard(Cards_fullDeck[randomNext(0, Cards_fullDeck.length)]);
}

export let drawnCard = createAtom("");

export const myButton = document.querySelector(".my-button");

myButton.onclick = ((_arg1) => {
    let arg10;
    drawnCard(Cards_drawOneAndPrintCard(), true);
    myButton.innerText = ((arg10 = drawnCard(), toText(printf("You pulled: %s "))(arg10)));
});

export const JsInteropDynamicCasting_shuffle = shuffle;

export const JsInteropDynamicCasting_deck = JsInteropDynamicCasting_shuffle.shuffle();

export const JsInteropDynamicCasting_card = JsInteropDynamicCasting_deck.draw();

export const myDeck = JsInteropDynamicCasting_deck;

export const JsInteropInterface_Shuffle = shuffle;

export const JsInteropInterface_playingCard = playingCard;

export const JsInteropInterface_newCard = new JsInteropInterface_playingCard("Heart", "Five", 5);

export class MyCard extends Record {
    constructor(Name) {
        super();
        this.Name = Name;
    }
    static create(name) {
        return new MyCard(name);
    }
    toString() {
        const this$ = this;
        const matchValue = this$.Name;
        if (matchValue === "Exodia") {
            return toText(interpolate("%P() 😱. That means you win!", [this$.Name]));
        }
        else {
            const anythingElse = matchValue;
            return toText(interpolate("%P()?? ..", [anythingElse]));
        }
    }
}

export function MyCard$reflection() {
    return record_type("App.MyCard", [], MyCard, () => [["Name", string_type]]);
}

export let drawnCard2 = createAtom(void 0);

export const deck = JsInteropInterface_Shuffle.shuffle();

export const myButton2 = document.querySelector(".my-button2");

myButton2.onclick = ((_arg1) => {
    let arg10;
    drawnCard2(deck.draw(), true);
    console.log(some(deck.length));
    myButton2.innerText = ((arg10 = value(drawnCard2()).toString(), toText(printf("You pulled: %s "))(arg10)));
});

export const myButton3 = document.querySelector(".my-button3");

myButton3.onclick = ((_arg1) => {
    const newCard = MyCard.create("Exodia");
    deck.putOnTopOfDeck([newCard]);
    console.log(some(deck.length));
});

